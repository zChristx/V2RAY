# ss-replit
REPL for replit.com to run shadowsocks server with v2ray-plugin

Just import this as REPL on replit.com and run. Console output will show credentials. Also password, Shadowsocks URL and QR code will be saved in newly created files in your REPL workspace.
